import { createClient } from '@/lib/supabase/server'
import Header from '@/components/layout/Header'
import Link from 'next/link'

const VEREDICTO_BADGE = {
  APROBADO: 'bg-aprobado text-white',
  APROBADO_CON_CAMBIOS: 'bg-cambios text-white',
  NO_PUBLICAR: 'bg-no-publicar text-white',
}

const VEREDICTO_LABEL = {
  APROBADO: 'Aprobado',
  APROBADO_CON_CAMBIOS: 'Con cambios',
  NO_PUBLICAR: 'No publicar',
}

export default async function HistorialPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: analyses } = await supabase
    .from('analyses')
    .select('id, created_at, file_type, veredicto, puntuacion')
    .eq('user_id', user?.id)
    .order('created_at', { ascending: false })
    .limit(100)

  return (
    <div className="min-h-screen bg-crema">
      <Header />
      <main className="max-w-2xl mx-auto px-4 py-10 space-y-8">

        <div className="text-center space-y-2">
          <h1 className="font-serif text-4xl font-bold text-dark-text">Mis análisis anteriores</h1>
          <div className="ornament">─────────────</div>
        </div>

        {!analyses || analyses.length === 0 ? (
          <div className="card text-center space-y-4 py-16">
            <div className="text-5xl">🐢</div>
            <p className="text-light-text">Aún no has analizado ningún contenido.</p>
            <Link href="/dashboard" className="btn-primary inline-flex">
              Analizar mi primer post
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {analyses.map((a) => {
              const fecha = new Date(a.created_at).toLocaleDateString('es-ES', {
                day: 'numeric', month: 'long', year: 'numeric'
              })
              return (
                <Link
                  key={a.id}
                  href={`/historial/${a.id}`}
                  className="card flex items-center justify-between hover:border-ocre/40 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{a.file_type === 'video' ? '🎬' : '🖼️'}</span>
                    <div>
                      <p className="text-sm font-semibold text-dark-text">{fecha}</p>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${VEREDICTO_BADGE[a.veredicto as keyof typeof VEREDICTO_BADGE]}`}>
                        {VEREDICTO_LABEL[a.veredicto as keyof typeof VEREDICTO_LABEL]}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-light-text">
                    <span className="font-serif text-lg font-semibold text-ocre">{a.puntuacion}/10</span>
                    <span>›</span>
                  </div>
                </Link>
              )
            })}
          </div>
        )}

      </main>
    </div>
  )
}
