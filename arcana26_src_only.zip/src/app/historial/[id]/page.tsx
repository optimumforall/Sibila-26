import { createClient } from '@/lib/supabase/server'
import { notFound } from 'next/navigation'
import Header from '@/components/layout/Header'
import ResultadoView from '@/components/ui/ResultadoView'

export default async function HistorialDetallePage({ params }: { params: { id: string } }) {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
  if (!uuidRegex.test(params.id)) notFound()

  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: analysis } = await supabase
    .from('analyses')
    .select('*')
    .eq('id', params.id)
    .eq('user_id', user?.id)
    .single()

  if (!analysis) notFound()

  return (
    <div className="min-h-screen bg-crema">
      <Header />
      <main className="max-w-2xl mx-auto px-4 py-10">
        <div className="text-center mb-8 space-y-2">
          <h1 className="font-serif text-4xl font-bold text-dark-text">Análisis anterior</h1>
          <div className="ornament">─────────────</div>
        </div>
        <ResultadoView analysis={analysis} showBack />
      </main>
    </div>
  )
}
