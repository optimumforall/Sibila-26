import { createClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'
import OpenAI from 'openai'
import { Resend } from 'resend'
import { AnalysisResult } from '@/types'

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
const resend = new Resend(process.env.RESEND_API_KEY)

const SYSTEM_PROMPT = `Eres el analizador de contenido de Arcana-26, una tarotista y terapeuta holística española.
Tu trabajo es analizar si el contenido es seguro para publicar en Instagram y coherente con la marca.

GUÍA DE MARCA ARCANA-26:
- Paleta: tierra, ocre #8B6F47, crema #F5EDD8, terracota #C4956A, verde salvia #7D9B76. NO azules fríos, NO negro puro.
- Elementos visuales aprobados: velas, cristales, cartas de tarot, flores, plantas, tortugas, cuencos tibetanos, incienso
- Tono: cálido, cercano, espiritual, femenino. NO oscuro, NO agresivo, NO frío.
- Vocabulario SÍ: "acompaño", "guía", "reflexión", "mensaje de las cartas", "conecta con tu intuición", "claridad", "autoconocimiento", "sabiduría"
- Vocabulario NO: "predicción", "predigo", "te digo el futuro", "adivino", "adivinación", "magia", "garantizo", "seguro que", "100%"
- Hashtags aprobados (usar 3-5 separados): #tarot #arcana-26 #cunit #espiritualidad #intuicion #autoconocimiento #fengshui #bienestarpersonal #crecimientopersonal #tarot-espiritualidad

REGLAS DE INSTAGRAM:
- Sin promesas de resultados concretos
- Sin lenguaje que implique adivinación del futuro
- Sin símbolos extremos o contenido perturbador
- Sin marcas de agua de herramientas de IA visibles

Devuelve SIEMPRE un JSON válido con esta estructura exacta (sin markdown, solo JSON puro):
{
  "veredicto": "APROBADO" | "APROBADO_CON_CAMBIOS" | "NO_PUBLICAR",
  "puntuacion": 1-10,
  "problemas": [{"tipo": "vocabulario|visual|hashtags|instagram", "descripcion": "..."}],
  "caption_sugerido": "caption corregido con 3-5 hashtags de la lista aprobada",
  "explicacion": "explicación breve en español para Juana, tono amable y cálido"
}`

// Rate limiting simple en memoria (se resetea con cada deploy)
const requestCounts = new Map<string, { count: number; resetAt: number }>()

function checkRateLimit(userId: string): boolean {
  const now = Date.now()
  const hourMs = 60 * 60 * 1000
  const existing = requestCounts.get(userId)

  if (!existing || now > existing.resetAt) {
    requestCounts.set(userId, { count: 1, resetAt: now + hourMs })
    return true
  }

  if (existing.count >= 5) return false // Máx 5/hora
  existing.count++
  return true
}

export async function POST(request: NextRequest) {
  try {
    // 1. Verificar sesión
    const supabase = createClient()
    const { data: { user }, error: authError } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    // 2. Rate limiting
    if (!checkRateLimit(user.id)) {
      return NextResponse.json(
        { error: 'Has alcanzado el límite de 5 análisis por hora. Inténtalo más tarde.' },
        { status: 429 }
      )
    }

    // 3. Leer el archivo y caption
    const formData = await request.formData()
    const file = formData.get('file') as File | null
    const caption = (formData.get('caption') as string) || ''

    if (!file) {
      return NextResponse.json({ error: 'No se recibió ningún archivo' }, { status: 400 })
    }

    // 4. Validar archivo
    const allowedTypes = ['video/mp4', 'video/quicktime', 'image/jpeg', 'image/png', 'image/webp']
    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json({ error: 'Formato de archivo no permitido' }, { status: 400 })
    }

    if (file.size > 100 * 1024 * 1024) {
      return NextResponse.json({ error: 'El archivo supera los 100MB' }, { status: 400 })
    }

    if (caption.length > 2200) {
      return NextResponse.json({ error: 'El caption supera los 2.200 caracteres' }, { status: 400 })
    }

    // 5. Subir archivo a Supabase Storage
    const fileExt = file.name.split('.').pop()
    const fileName = `${user.id}/${Date.now()}.${fileExt}`
    const fileBuffer = await file.arrayBuffer()

    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('content-uploads')
      .upload(fileName, fileBuffer, { contentType: file.type })

    if (uploadError) {
      return NextResponse.json({ error: 'Error al subir el archivo' }, { status: 500 })
    }

    const { data: { publicUrl } } = supabase.storage
      .from('content-uploads')
      .getPublicUrl(fileName)

    // 6. Determinar tipo
    const fileType = file.type.startsWith('video') ? 'video' : 'image'
    let transcription: string | null = null

    // 7. Si es vídeo, transcribir audio con Whisper
    if (fileType === 'video') {
      try {
        const audioFile = new File([fileBuffer], `audio.${fileExt}`, { type: file.type })
        const transcriptionResult = await openai.audio.transcriptions.create({
          file: audioFile,
          model: 'whisper-1',
          language: 'es',
        })
        transcription = transcriptionResult.text
      } catch {
        // Si Whisper falla, continuamos sin transcripción
        transcription = null
      }
    }

    // 8. Analizar con Claude
    const userContent: Anthropic.MessageParam['content'] = []

    // Añadir imagen o frame del vídeo
    const imageBuffer = Buffer.from(fileBuffer)
    const base64Image = imageBuffer.toString('base64')
    const imageMediaType = fileType === 'video' ? 'image/jpeg' : file.type as 'image/jpeg' | 'image/png' | 'image/webp'

    userContent.push({
      type: 'image',
      source: {
        type: 'base64',
        media_type: imageMediaType,
        data: base64Image,
      }
    })

    // Texto de análisis
    let textPrompt = 'Analiza este contenido para Instagram:'
    if (transcription) textPrompt += `\n\nTranscripción del audio: "${transcription}"`
    if (caption) textPrompt += `\n\nCaption escrito: "${caption}"`

    userContent.push({ type: 'text', text: textPrompt })

    const claudeResponse = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1000,
      system: SYSTEM_PROMPT,
      messages: [{ role: 'user', content: userContent }],
    })

    const responseText = claudeResponse.content[0].type === 'text' ? claudeResponse.content[0].text : ''
    let result: AnalysisResult

    try {
      result = JSON.parse(responseText)
    } catch {
      // Intentar extraer JSON si viene con texto extra
      const match = responseText.match(/\{[\s\S]*\}/)
      if (match) {
        result = JSON.parse(match[0])
      } else {
        throw new Error('No se pudo parsear la respuesta de Claude')
      }
    }

    // 9. Guardar en Supabase
    const { data: analysisData, error: dbError } = await supabase
      .from('analyses')
      .insert({
        user_id: user.id,
        file_url: publicUrl,
        file_type: fileType,
        caption_original: caption || null,
        transcription: transcription,
        veredicto: result.veredicto,
        puntuacion: result.puntuacion,
        problemas: result.problemas,
        caption_sugerido: result.caption_sugerido,
        explicacion: result.explicacion,
      })
      .select('id')
      .single()

    if (dbError || !analysisData) {
      return NextResponse.json({ error: 'Error al guardar el análisis' }, { status: 500 })
    }

    // 10. Enviar email (no bloqueante)
    const veredictoEmoji = { APROBADO: '✅', APROBADO_CON_CAMBIOS: '⚠️', NO_PUBLICAR: '❌' }
    resend.emails.send({
      from: 'Arcana-26 <noreply@tudominio.com>',
      to: process.env.JUANA_EMAIL!,
      subject: `[Arcana-26] ${veredictoEmoji[result.veredicto]} ${result.veredicto} — Puntuación: ${result.puntuacion}/10`,
      html: `
        <h2>Resultado del análisis</h2>
        <p><strong>Veredicto:</strong> ${result.veredicto}</p>
        <p><strong>Puntuación:</strong> ${result.puntuacion}/10</p>
        <p><strong>Explicación:</strong> ${result.explicacion}</p>
        ${result.problemas.length > 0 ? `<p><strong>Problemas:</strong> ${result.problemas.map(p => p.descripcion).join(', ')}</p>` : ''}
        <p><strong>Caption sugerido:</strong> ${result.caption_sugerido}</p>
      `
    }).catch(() => {}) // Si falla el email, no afecta al resultado

    return NextResponse.json({ id: analysisData.id })

  } catch (error) {
    console.error('Error en /api/analyze:', error)
    return NextResponse.json(
      { error: 'El análisis no está disponible ahora. Inténtalo en unos minutos.' },
      { status: 500 }
    )
  }
}
