'use client'

import { useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import Header from '@/components/layout/Header'

const MAX_SIZE_MB = 100
const MAX_CAPTION_CHARS = 2200
const ALLOWED_TYPES = ['video/mp4', 'video/quicktime', 'image/jpeg', 'image/png', 'image/webp']

export default function Dashboard() {
  const [file, setFile] = useState<File | null>(null)
  const [caption, setCaption] = useState('')
  const [loading, setLoading] = useState(false)
  const [progress, setProgress] = useState('')
  const [error, setError] = useState('')
  const fileInputRef = useRef<HTMLInputElement>(null)
  const router = useRouter()

  function handleFileSelect(selected: File) {
    setError('')
    if (!ALLOWED_TYPES.includes(selected.type)) {
      setError('Formato no compatible. Sube un MP4, MOV, JPG, PNG o WEBP.')
      return
    }
    if (selected.size > MAX_SIZE_MB * 1024 * 1024) {
      setError('El archivo es demasiado grande. Máximo 100MB.')
      return
    }
    setFile(selected)
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault()
    const dropped = e.dataTransfer.files[0]
    if (dropped) handleFileSelect(dropped)
  }

  async function handleAnalyze() {
    if (!file) return
    setLoading(true)
    setError('')

    const formData = new FormData()
    formData.append('file', file)
    formData.append('caption', caption)

    const messages = [
      'Subiendo archivo...',
      file.type.startsWith('video') ? 'Escuchando tu vídeo...' : 'Procesando imagen...',
      'Analizando con IA...',
      'Casi listo...',
    ]

    let msgIndex = 0
    setProgress(messages[0])
    const interval = setInterval(() => {
      msgIndex = Math.min(msgIndex + 1, messages.length - 1)
      setProgress(messages[msgIndex])
    }, 8000)

    try {
      const res = await fetch('/api/analyze', { method: 'POST', body: formData })
      clearInterval(interval)

      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || 'Error desconocido')
      }

      const { id } = await res.json()
      router.push(`/resultado/${id}`)
    } catch (err: any) {
      clearInterval(interval)
      setError(err.message || 'El análisis no está disponible ahora. Inténtalo en unos minutos.')
      setLoading(false)
      setProgress('')
    }
  }

  const captionOverLimit = caption.length > MAX_CAPTION_CHARS

  return (
    <div className="min-h-screen bg-crema">
      <Header />
      <main className="max-w-2xl mx-auto px-4 py-10 space-y-8">

        {/* Título */}
        <div className="text-center space-y-2">
          <h1 className="font-serif text-4xl font-bold text-dark-text">Analiza tu contenido</h1>
          <p className="text-light-text">Sube tu vídeo o imagen antes de publicar en Instagram</p>
          <div className="ornament">─────────────</div>
        </div>

        {/* Zona de subida */}
        <div
          className={`border-2 border-dashed rounded-2xl p-10 text-center cursor-pointer transition-colors
            ${file ? 'border-aprobado bg-green-50' : 'border-ocre/50 hover:border-ocre bg-off-white'}`}
          onDrop={handleDrop}
          onDragOver={(e) => e.preventDefault()}
          onClick={() => !file && fileInputRef.current?.click()}
        >
          {file ? (
            <div className="space-y-3">
              <div className="text-4xl">{file.type.startsWith('video') ? '🎬' : '🖼️'}</div>
              <p className="font-semibold text-dark-text">{file.name}</p>
              <p className="text-sm text-light-text">{(file.size / 1024 / 1024).toFixed(1)} MB</p>
              <button
                onClick={(e) => { e.stopPropagation(); setFile(null) }}
                className="text-sm text-red-500 hover:text-red-700 underline"
              >
                Eliminar archivo
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="text-4xl">☁️</div>
              <p className="font-semibold text-dark-text">Arrastra tu vídeo o imagen aquí</p>
              <p className="text-sm text-light-text">MP4, MOV, JPG, PNG, WEBP · Máximo 100MB</p>
              <button className="btn-secondary text-sm px-4 py-2">Seleccionar archivo</button>
            </div>
          )}
        </div>
        <input
          ref={fileInputRef}
          type="file"
          className="hidden"
          accept=".mp4,.mov,.jpg,.jpeg,.png,.webp"
          onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
        />

        {/* Error de archivo */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-700">
            {error}
          </div>
        )}

        {/* Caption */}
        <div className="space-y-2">
          <label className="block text-sm font-semibold text-dark-text">
            Texto que vas a poner en Instagram{' '}
            <span className="font-normal text-light-text">(opcional)</span>
          </label>
          <textarea
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            placeholder="Hoy las cartas nos traen un mensaje de esperanza..."
            rows={5}
            className={`w-full rounded-xl border p-4 text-sm resize-none bg-off-white focus:outline-none focus:ring-2 focus:ring-ocre/30
              ${captionOverLimit ? 'border-red-400' : 'border-crema'}`}
          />
          <div className={`text-xs text-right ${captionOverLimit ? 'text-red-500 font-semibold' : 'text-light-text'}`}>
            {caption.length} / {MAX_CAPTION_CHARS}
          </div>
        </div>

        {/* Botón analizar */}
        <button
          onClick={handleAnalyze}
          disabled={!file || loading || captionOverLimit}
          className="btn-primary w-full text-base py-4"
        >
          {loading ? (
            <span className="flex items-center gap-2">
              <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
              </svg>
              {progress}
            </span>
          ) : (
            'Analizar mi contenido →'
          )}
        </button>

      </main>
    </div>
  )
}
